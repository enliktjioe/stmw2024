#!/bin/bash

mysql --local-infile=1 ad < queries.sql